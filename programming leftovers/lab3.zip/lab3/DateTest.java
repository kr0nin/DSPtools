
/**
 * Write a description of class DateTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DateTest
{
    static public void test()
    {
        Date dt = new Date(1, 1, 2010);
        System.out.println(dt);
        dt.advance();
        System.out.println(dt);
        dt.advanceD(29);
        System.out.println(dt);
        dt.advanceW(4);
        int i = 0;
        while (i < 365)
        {
            dt.advance();
            System.out.println(dt);
            i++;
            }
        }
}
