
/**
 * Write a description of class Game here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
public class Game
{
    private int prize_door = (int)(Math.random()*3+1);
    private Door door1 = new Door(1, random(1));
    private Door door2 = new Door(2, random(2));
    private Door door3 = new Door(3, random(3));
    private Door doorX[] = {door1, door2, door3};
    public boolean random(int n)
    {
        if (n == prize_door)
            return true;
        else return false;
        }
    public Game()  {  }
    public Door initialGuess(int door)
    {
        int unveil = (int) (Math.random()*2);
        int revealed;
        do
            revealed = (int)(Math.random()*3+1);
        while (revealed == door || doorX[revealed-1].isWinner());
        if (revealed ==1)
        {
            door1.open();
            return door1;
            }
        else if (revealed == 2)
        {
            door2.open();
            return door2;
            }
        else
        {
            door3.open();
            return door3;
            }
        }
    public Door finalGuess(int door)
    {
        switch (door)
        {
            case 1: door1.open(); break;
            case 2: door2.open(); break;
            case 3: door3.open(); break;
            }
        if (door ==1)
            return door1;
        else if (door == 2)
            return door2;
        else return door3;
        }
    public String toString()
    {
        return door1.toString() + " " + door2.toString() + " " + door3.toString();
        }
}
