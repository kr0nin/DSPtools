/**
 * The test class DoorTest.
 *
 * @author  Abe Pralle
 * @version 2009.01.30
 */
public class DoorTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class DoorTest
     */
    public DoorTest()
    {
    }
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }
    public void test_door1_loser()
    {   
        Door door1_loser = new Door(1, false);
        assertEquals("[----]", door1_loser.toString());
        assertEquals(1, door1_loser.getNumber());
        assertEquals("?", door1_loser.getPrize());
        assertEquals(false, door1_loser.isWinner());
        assertEquals(false, door1_loser.open());
        assertEquals("Goat", door1_loser.getPrize());
        assertEquals("[Goat]", door1_loser.toString());
    }
    public void test_door3_winner()
    {
        Door door3_winner = new Door(3, true);
        assertEquals("[----]", door3_winner.toString());
        assertEquals(3, door3_winner.getNumber());
        assertEquals("?", door3_winner.getPrize());
        assertEquals(true, door3_winner.isWinner());
        assertEquals(true, door3_winner.open());
        assertEquals("Car", door3_winner.getPrize());
        assertEquals("[Car!]", door3_winner.toString());
    }
}