
/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door
{
    private int door_number = 0;
    private boolean is_open = false;
    private boolean is_winner = false;
    public Door(int door_number, boolean is_winner)
    {
        this.is_winner = is_winner;
        this.door_number= door_number;
        }
    public int getNumber()  {  return door_number;  }
    public boolean isWinner()  {  return is_winner;  }
    public boolean isOpen()  {  return is_open;  }
    public boolean open()
    {
        is_open = true;
        return is_winner;
        }
    public String getPrize()
    {
        if (is_open && isWinner())
            return "Car";
        else if (is_open)
            return "Goat";
        else return "?";
        }
    public String toString()
    {
        if (is_open && isWinner())
            return "[Car!]";
        else if (is_open)
            return "[Goat]";
        else return "[----]";
        }
}
