//====================================================================
//    MontyHall.java
//
//    Drives a text game based around the Monty Hall problem.
//
//    2009.01.30 by Abe Pralle
//====================================================================
import java.util.*;

public class MontyHall
{
    private Scanner kb;
    private int wins, losses;

    static public void main( String[] args )
    {
        new MontyHall().play();
    }

    public MontyHall()
    {
        kb = new Scanner( System.in );
    }

    private int inputDoorNumber( String message )
    {
        System.out.print( message );
        while (true)
        {
            try
            {
                int n = kb.nextInt();
                if (n >= 1 && n <= 3) return n;
                System.out.print( "Enter 1, 2, or 3: " );
            }
            catch (NumberFormatException err) { }
        }
    }

    public void play()
    {
        while (true)
        {
            System.out.println( "New Game" );
            Game game = new Game();
            System.out.println( game );

            int    initial_choice = inputDoorNumber( "Pick a door: " );
            Door revealed = game.initialGuess( initial_choice );
            System.out.println( "The host opens door #" + revealed.getNumber() 
                    + " to reveal a " + revealed.getPrize() + "." );
            int    remaining_choice = (1+2+3) - initial_choice - revealed.getNumber();
            System.out.println( game );

            System.out.println( "You can switch your choice to door #" 
                    + remaining_choice + " if you want." );
            int final_choice = inputDoorNumber( "What is your final choice? " );
            while (final_choice != initial_choice && final_choice != remaining_choice)
            {
                System.out.println( "You must pick door #" + initial_choice 
                        + " or door #" + remaining_choice + "!" );
                final_choice = inputDoorNumber( "What is your final choice? " );
            }

            Door final_door= game.finalGuess(final_choice);
            System.out.println( game );
            if (final_door.isWinner())
            {
                System.out.println( "You win!" );
                wins++;
            }
            else
            {
                System.out.println( "You lose." );
                losses++;
            }

            System.out.println( "Score: " + wins + "/" + (wins+losses)
                    + " (" + Math.floor(wins * 100.0 / (wins+losses) + 0.5) + "%)\n" );
        }
    }
}